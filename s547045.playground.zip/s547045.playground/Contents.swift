import UIKit

var greeting = "Hello, playground"
print("my name is bhavishya")
